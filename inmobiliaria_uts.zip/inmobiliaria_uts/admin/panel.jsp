<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*" %>
<%--
 admin/panel.jsp - Panel del rol administrador: resumen, acceso rapido al
 modulo de administracion (usuarios y roles, catalogos, auditoria, reportes).
 Protegido por el fragmento seguridad.jspf (rolesPermitidos) y por
 SeguridadFilter (ruta /admin/*).
--%>
<%
  String[] rolesPermitidos = { "administrador" };
  String tituloPagina = "Panel de administracion";
%>
<%@ include file="/WEB-INF/jspf/seguridad.jspf" %>
<%@ include file="/WEB-INF/jspf/conexion.jspf" %>
<%
  int totalUsuarios = 0;
  int usuariosActivos = 0;
  int totalCiudades = 0;
  int totalTipos = 0;
  int totalCaracteristicas = 0;
  long totalAuditoria = 0;
  String errorPanel = null;

  Connection con = null;
  PreparedStatement ps = null;
  ResultSet rs = null;
  try {
    con = abrirConexion();
    ps = con.prepareStatement(
        "SELECT COUNT(*), SUM(CASE WHEN estado = 'activo' THEN 1 ELSE 0 END) FROM usuario");
    rs = ps.executeQuery();
    if (rs.next()) {
      totalUsuarios = rs.getInt(1);
      usuariosActivos = rs.getInt(2);
    }
    cerrar(rs, ps);

    ps = con.prepareStatement("SELECT COUNT(*) FROM ciudad");
    rs = ps.executeQuery();
    if (rs.next()) totalCiudades = rs.getInt(1);
    cerrar(rs, ps);

    ps = con.prepareStatement("SELECT COUNT(*) FROM tipo_propiedad");
    rs = ps.executeQuery();
    if (rs.next()) totalTipos = rs.getInt(1);
    cerrar(rs, ps);

    ps = con.prepareStatement("SELECT COUNT(*) FROM caracteristica");
    rs = ps.executeQuery();
    if (rs.next()) totalCaracteristicas = rs.getInt(1);
    cerrar(rs, ps);

    ps = con.prepareStatement("SELECT COUNT(*) FROM auditoria");
    rs = ps.executeQuery();
    if (rs.next()) totalAuditoria = rs.getLong(1);
  } catch (Exception e) {
    e.printStackTrace();
    errorPanel = "No se pudo cargar el resumen. Intente mas tarde.";
  } finally {
    cerrar(rs, ps, con);
  }
%>
<%@ include file="/WEB-INF/jspf/cabecera.jspf" %>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
    <div>
        <h1 class="h4 fw-bold mb-1">Panel del administrador</h1>
        <p class="text-muted mb-0">Bienvenido, <%=esc(nombreSesion)%>.</p>
    </div>
</div>

<% if (errorPanel != null) { %>
    <div class="alert alert-danger rounded-4"><i class="bi bi-exclamation-triangle me-1"></i><%=errorPanel%></div>
<% } %>

<div class="row g-3">
    <div class="col-md-4 col-lg-2">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-body text-center">
                <span class="ims-stat-icon"><i class="bi bi-people"></i></span>
                <div class="fw-bold fs-3"><%=totalUsuarios%></div>
                <div class="text-muted small">Usuarios (<%=usuariosActivos%> activos)</div>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-lg-2">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-body text-center">
                <span class="ims-stat-icon"><i class="bi bi-geo-alt"></i></span>
                <div class="fw-bold fs-3"><%=totalCiudades%></div>
                <div class="text-muted small">Ciudades</div>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-lg-2">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-body text-center">
                <span class="ims-stat-icon"><i class="bi bi-house-check"></i></span>
                <div class="fw-bold fs-3"><%=totalTipos%></div>
                <div class="text-muted small">Tipos de propiedad</div>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-lg-2">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-body text-center">
                <span class="ims-stat-icon"><i class="bi bi-list-check"></i></span>
                <div class="fw-bold fs-3"><%=totalCaracteristicas%></div>
                <div class="text-muted small">Caracteristicas</div>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-lg-2">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-body text-center">
                <span class="ims-stat-icon"><i class="bi bi-journal-check"></i></span>
                <div class="fw-bold fs-3"><%=totalAuditoria%></div>
                <div class="text-muted small">Registros de auditoria</div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mt-2">
    <div class="col-md-6 col-lg-3">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-header bg-transparent fw-bold"><i class="bi bi-people-fill me-1"></i> Usuarios</div>
            <div class="card-body small">
                <p class="text-muted mb-3">Asignar o revocar roles (usuario_rol) y activar/inactivar cuentas. Unica via para crear administradores e inmobiliarias.</p>
                <a class="btn ims-btn rounded-pill px-3 w-100" href="<%=ctx%>/admin/usuarios.jsp"><i class="bi bi-person-gear me-1"></i> Administrar usuarios</a>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-header bg-transparent fw-bold"><i class="bi bi-sliders me-1"></i> Catalogos</div>
            <div class="card-body small">
                <p class="text-muted mb-3">CRUD simple de ciudad, tipo_propiedad y caracteristica, que alimentan las propiedades.</p>
                <a class="btn ims-btn rounded-pill px-3 w-100" href="<%=ctx%>/admin/catalogos.jsp"><i class="bi bi-sliders me-1"></i> Gestionar catalogos</a>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-header bg-transparent fw-bold"><i class="bi bi-journal-text me-1"></i> Auditoria</div>
            <div class="card-body small">
                <p class="text-muted mb-3">Listado filtrable de la tabla auditoria por usuario, tipo de accion y fechas.</p>
                <a class="btn ims-btn rounded-pill px-3 w-100" href="<%=ctx%>/admin/auditoria.jsp"><i class="bi bi-journal-text me-1"></i> Consultar auditoria</a>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-header bg-transparent fw-bold"><i class="bi bi-graph-up me-1"></i> Reportes</div>
            <div class="card-body small">
                <p class="text-muted mb-3">Cinco consultas para la sustentacion (INNER JOIN, N:M, LEFT JOIN, GROUP BY + HAVING).</p>
                <a class="btn ims-btn rounded-pill px-3 w-100" href="<%=ctx%>/admin/reportes.jsp"><i class="bi bi-graph-up me-1"></i> Ver reportes</a>
            </div>
        </div>
    </div>
</div>
<%@ include file="/WEB-INF/jspf/utilidades.jspf" %>
<%@ include file="/WEB-INF/jspf/pie.jspf" %>