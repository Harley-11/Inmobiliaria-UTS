-- =====================================================================
-- INMOBILIARIA UTS - SCRIPT DML (datos de prueba)
-- Credenciales: <correo> con clave "1234"
-- El hash es SHA-256("correo:1234") en minusculas (patron usuario:clave).
-- Ejecutar DESPUES de 01_DDL_inmobiliaria_uts.sql
-- =====================================================================

USE inmobiliaria_uts;

-- ---------------------------------------------------------------------
-- ROLES
-- ---------------------------------------------------------------------
INSERT INTO rol (id_rol, nombre_rol) VALUES
  (1, 'administrador'),
  (2, 'inmobiliaria'),
  (3, 'cliente');

-- ---------------------------------------------------------------------
-- USUARIOS (clave comun: 1234 -> SHA-256 de "correo:1234")
-- ---------------------------------------------------------------------
INSERT INTO usuario (id_usuario, correo, contrasena_hash, estado, fecha_registro) VALUES
  (1,  'admin@inmobiliaria.com',     'e508c67b995f58e2b7466846003d1d3b27033ff5c4c2b13f3f1c7731fa33cee5', 'activo',   '2026-01-10 08:00:00'),
  (2,  'gerencia@inmobiliaria.com',  '73ca24e1584d9e811f824441887453bca1dc7a464f650ad85fe9dd55d3765903', 'activo',   '2026-01-12 09:00:00'),
  (3,  'inmobiliaria1@inmobiliaria.com', 'bf1e1fdbfd575cd1e335dfff6b912edc4034b13263f1d9d59eb52b7776c57060', 'activo', '2026-01-15 10:00:00'),
  (4,  'inmobiliaria2@inmobiliaria.com', 'a3d3409648e5baeac597b00bd1af433182e895cf69bebfa7c5d29686b4320f76', 'activo', '2026-01-20 11:00:00'),
  (5,  'agente1@inmobiliaria.com',   '088571255ea8342acd843121972c6e39b9060fca2e033586e3211c494dcc134d', 'activo',   '2026-01-22 12:00:00'),
  (6,  'juan.perez@cliente.com',     'cb827792acea16dd97bd62a89f53a3047be55d41370df7aa4906468a795aef46', 'activo',   '2026-02-01 10:30:00'),
  (7,  'maria.gomez@cliente.com',    '52569ddef41436bd34ead8e7cec65538be9656024ef673b0aa878367af8a646e', 'activo',   '2026-02-02 09:15:00'),
  (8,  'carlos.ruiz@cliente.com',    '378374cc38196f6eba1f77f960e0ab25eebcd17de7f52eacdb57ba47aa30059e', 'activo',   '2026-02-03 11:45:00'),
  (9,  'ana.torres@cliente.com',     '90609b38bb3c157e4ed0f80d8056b13a51c4cc845ba7a78c1dae24782cff4895', 'activo',   '2026-02-05 14:20:00'),
  (10, 'luis.ramirez@cliente.com',   '3261a40d58191f5b8e882022a1eff8b5c7f2da30c96094940487b13e613e87ac', 'inactivo', '2026-02-07 16:00:00'),
  (11, 'central@inmobiliaria.com',   '8100118de5f9ebb6b5f7411fbd01f27e03b28d569066d76076c6f34980b76a4f', 'activo',   '2026-03-01 09:00:00'),
  (12, 'andina@inmobiliaria.com',    '47e20cfffd2cf1a1254387d8b9a60843dab699b2c1c5e1b162ce6cd48f8cc135', 'activo',   '2026-03-02 10:00:00'),
  (13, 'vision@inmobiliaria.com',    'ef2e0607f220d6cd01567ef86997f1174fb3754fbf7803ab6f33f78ec74f7308', 'activo',   '2026-03-03 11:00:00'),
  (14, 'urbana@inmobiliaria.com',    'ac2ea532ea3af74d595c2434e3db63d59fa981289ee20dd22589fd7579ee0ff1', 'activo',   '2026-03-04 12:00:00'),
  (15, 'gloria@inmobiliaria.com',    '840672e6a47dab68963170c21adba89730884cfe382b08f7480872ab0082b05d', 'activo',   '2026-03-05 13:00:00'),
  (16, 'norte@inmobiliaria.com',     '8ff903b6f7bc5811f1f5182b03a00377036f16d6add12f800c2a9313f066fd80', 'activo',   '2026-03-06 14:00:00'),
  (17, 'dorada@inmobiliaria.com',    '6c0784870d1de848bb0e30a52f40b93d974ff244310529372eb43f3b7d5e1066', 'activo',   '2026-03-07 15:00:00'),
  (18, 'oriente@inmobiliaria.com',   '7d071136d7444c5809ceced03816e0409c84fc3f1fa07b000765d584ed2bad12', 'activo',   '2026-03-08 16:00:00');

-- ---------------------------------------------------------------------
-- USUARIO_ROL (asignaciones de rol)
-- ---------------------------------------------------------------------
INSERT INTO usuario_rol (id_usuario, id_rol) VALUES
  (1, 1),  -- admin            -> administrador
  (2, 1),  -- gerencia         -> administrador
  (3, 2),  -- inmobiliaria1    -> inmobiliaria
  (4, 2),  -- inmobiliaria2    -> inmobiliaria
  (5, 2),  -- agente1          -> inmobiliaria (rol unico, sin duplicado)
  (6, 3),  -- juan             -> cliente
  (7, 3),  -- maria            -> cliente
  (8, 3),  -- carlos           -> cliente
  (9, 3),  -- ana              -> cliente
  (10, 3), -- luis             -> cliente (inactivo)
  (11, 2), (12, 2), (13, 2), (14, 2), (15, 2), (16, 2), (17, 2), (18, 2);

-- ---------------------------------------------------------------------
-- PERFILES
-- ---------------------------------------------------------------------
INSERT INTO perfil (id_perfil, id_usuario, nombres, apellidos, documento, telefono, direccion, foto) VALUES
  (1,  1,  'Administrador',       'UTS Plataforma',  '1000000001', '3120000001', 'Cra 27 # 10-04, Bucaramanga', NULL),
  (2,  2,  'Gerencia General',    'Inmobiliaria UTS', '1000000002', '3120000002', 'Cra 27 # 10-04, Bucaramanga', NULL),
  (3,  3,  'Carlos Alberto',      'Gomez Rincon',     '91234567',    '3001234567', 'Calle 45 # 28-90, Bucaramanga', NULL),
  (4,  4,  'Diana Carolina',      'Rodriguez Prada',  '80123456',    '3007654321', 'Av. Santander # 15-20, Floridablanca', NULL),
  (5,  5,  'Andres Felipe',       'Martinez Luna',    '79876543',    '3012345678', 'Calle 31 # 30-12, Bucaramanga', NULL),
  (6,  6,  'Juan David',          'Perez Sanchez',    '1012345678',  '3151234567', 'Calle 48 # 29-14, Cabecera', NULL),
  (7,  7,  'Maria Fernanda',      'Gomez Ortiz',      '1002345678',  '3157654321', 'Cra 21 # 30-45, Cabecera', NULL),
  (8,  8,  'Carlos Andres',       'Ruiz Torres',      '1098765432',  '3172345678', 'Calle 50 # 25-40, Cabecera', NULL),
  (9,  9,  'Ana Sofia',           'Torres Vega',      '1023456789',  '3113456789', 'Cra 34 # 29-10, Cabecera', NULL),
  (10, 10, 'Luis Eduardo',        'Ramirez Moreno',   '1056789012',  '3134567890', 'Cra 19 # 22-60, Alarcón', NULL),
  (11, 11, 'Ricardo',             'Camargo Pineda',   '1090456789',  '3001112233', 'Cra 30 # 52-40, Bucaramanga', NULL),
  (12, 12, 'Paula Andrea',        'Suarez Rangel',    '52789123',    '3002223344', 'Calle 45 # 27-10, Bucaramanga', NULL),
  (13, 13, 'Julian',              'Ospina Garzon',    '1091567890',  '3003334455', 'Calle 52 # 20-30, Bucaramanga', NULL),
  (14, 14, 'Laura Vanessa',       'Rincon Pardo',     '1092678901',  '3004445566', 'Cra 24 # 46-18, Bucaramanga', NULL),
  (15, 15, 'Oscar',               'Villamizar Mesa',  '1093789012',  '3005556677', 'Calle 34 # 19-25, Bucaramanga', NULL),
  (16, 16, 'Natalia',             'Quintero Jerez',   '1094890123',  '3006667788', 'Av. La Rosita # 12-45, Floridablanca', NULL),
  (17, 17, 'Sebastian',           'Mantilla Rueda',   '1095901234',  '3007778899', 'Calle 61 # 12-30, Bucaramanga', NULL),
  (18, 18, 'Valentina',           'Bohorquez Nino',   '1096012345',  '3008889900', 'Cra 27 # 41-23, Bucaramanga', NULL);

-- ---------------------------------------------------------------------
-- CIUDADES
-- ---------------------------------------------------------------------
INSERT INTO ciudad (id_ciudad, nombre_ciudad, departamento) VALUES
  (1, 'Bucaramanga',     'Santander'),
  (2, 'Floridablanca',   'Santander'),
  (3, 'Piedecuesta',     'Santander'),
  (4, 'Girón',           'Santander'),
  (5, 'Cúcuta',          'Norte de Santander'),
  (6, 'Barrancabermeja', 'Santander'),
  (7, 'San Gil',         'Santander'),
  (8, 'Ocaña',           'Norte de Santander'),
  (9, 'Valledupar',      'Cesar'),
  (10, 'Sogamoso',       'Boyacá');

-- ---------------------------------------------------------------------
-- TIPOS DE PROPIEDAD
-- ---------------------------------------------------------------------
INSERT INTO tipo_propiedad (id_tipo, nombre_tipo) VALUES
  (1, 'Apartamento'),
  (2, 'Casa'),
  (3, 'Local Comercial'),
  (4, 'Oficina'),
  (5, 'Lote'),
  (6, 'Bodega'),
  (7, 'Finca'),
  (8, 'Apartaestudio'),
  (9, 'Consultorio'),
  (10, 'Parqueadero');

-- ---------------------------------------------------------------------
-- INMOBILIARIAS
-- ---------------------------------------------------------------------
INSERT INTO inmobiliaria (id_inmobiliaria, id_usuario, nombre_comercial, nit) VALUES
  (1, 3,  'Inmobiliaria UTS',      '900123456-1'),
  (2, 4,  'FincaRaíz Santander',   '901234567-2'),
  (3, 11, 'Central Inmobiliaria',  '902345678-3'),
  (4, 12, 'Andina Bienes Raíces',  '903456789-4'),
  (5, 13, 'Visión Inmobiliaria',   '904567890-5'),
  (6, 14, 'Urbana Inmobiliaria',   '905678901-6'),
  (7, 15, 'Inmobiliaria La Gloria','906789012-7'),
  (8, 16, 'Inmobiliaria Norte',    '907890123-8'),
  (9, 17, 'Inmobiliaria La Dorada','908901234-9'),
  (10, 18, 'Oriente Inmobiliaria', '909012345-0'),
  (11, 5,  'Inmobiliaria Agente Uno','901234568-5'); -- agente1 -> su propia inmobiliaria

-- ---------------------------------------------------------------------
-- PROPIEDADES (12 registros)
-- ---------------------------------------------------------------------
INSERT INTO propiedad (id_propiedad, id_inmobiliaria, id_ciudad, id_tipo, matricula_inmobiliaria,
                       titulo, descripcion, precio, direccion, estado, fecha_publicacion) VALUES
  (1,  1, 1, 1, '300-000001', 'Apartamento en Cabecera',
       'Apartamento de lujo, piso 6, iluminado, cerca a parques y centro comercial.', 450000000.00,
       'Cra 33 # 48-20, Cabecera', 'disponible', '2026-08-05 09:00:00'),
  (2,  1, 2, 2, '300-000002', 'Casa en Cañaveral',
       'Casa de 2 pisos en condominio cerrado con zona social.', 380000000.00,
       'Cra 21 # 40-15, Cañaveral', 'disponible', '2026-08-07 10:00:00'),
  (3,  2, 1, 3, '300-000003', 'Local Comercial Centro',
       'Local en primera planta, esquina, alto flujo peatonal.', 220000000.00,
       'Calle 35 # 10-25, Centro', 'disponible', '2026-08-10 14:00:00'),
  (4,  2, 5, 4, '300-000004', 'Oficina Av. Libertadores',
       'Oficina amoblada, edificio ejecutivo con recepción.', 180000000.00,
       'Av. Libertadores # 12-80, Cúcuta', 'arrendado', '2026-08-12 11:00:00'),
  (5,  1, 3, 5, '300-000005', 'Lote en Ruitoque',
       'Lote urbanizable con vista panorámica, plugins de agua y luz.', 95000000.00,
       'Vereda Ruitoque, sector alto', 'disponible', '2026-08-15 09:30:00'),
  (6,  1, 4, 2, '300-000006', 'Casa campestre en Girón',
       'Casa campestre con piscina, zonas verdes y amplio garaje.', 520000000.00,
       'Vereda Bocas, Girón', 'disponible', '2026-08-18 15:00:00'),
  (7,  2, 6, 1, '300-000007', 'Apartamento Sotomayor',
       'Apartamento en el centro de Barrancabermeja, listo para estrenar.', 165000000.00,
       'Cra 12 # 20-45, Sotomayor', 'vendido', '2026-08-20 08:00:00'),
  (8,  1, 2, 6, '300-000008', 'Bodega zona industrial',
       'Bodega con patio de maniobras y oficina interna.', 310000000.00,
       'Vía Girón-Floridablanca km 4', 'disponible', '2026-08-25 10:00:00'),
  (9,  1, 1, 1, '300-000009', 'Apartamento Real de Minas',
       'Apartamento segundo piso, balcón y parqueadero.', 260000000.00,
       'Cra 15 # 29-12, Real de Minas', 'arrendado', '2026-08-28 12:00:00'),
  (10, 2, 7, 3, '300-000010', 'Local Centro San Gil',
       'Local ubicado en pleno centro comercial de San Gil.', 130000000.00,
       'Calle 12 # 8-30, Centro', 'disponible', '2026-08-30 16:00:00'),
  (11, 1, 4, 2, '300-000011', 'Casa en Altos de Girón',
       'Casa en conjunto residencial. Baja lógica: se retiró temporalmente.',
       290000000.00, 'Conjunto Altos de Girón', 'inactivo', '2026-09-01 09:00:00'),
  (12, 2, 9, 1, '300-000012', 'Apartamento en Valledupar',
       'Apartamento exterior, cerca al parque de la Leyenda Vallenata.', 200000000.00,
       'Cra 9 # 16-08, Centro', 'disponible', '2026-09-05 10:00:00');

-- ---------------------------------------------------------------------
-- CARACTERISTICAS
-- ---------------------------------------------------------------------
INSERT INTO caracteristica (id_caracteristica, nombre_caracteristica) VALUES
  (1, 'Habitaciones'),
  (2, 'Baños'),
  (3, 'Parqueaderos'),
  (4, 'Metros construidos'),
  (5, 'Metros de terreno'),
  (6, 'Antigüedad'),
  (7, 'Estrato'),
  (8, 'Piscina'),
  (9, 'Cuarto de servicio'),
  (10, 'Balcón');

-- ---------------------------------------------------------------------
-- PROPIEDAD_CARACTERISTICA (relacion N:M)
-- ---------------------------------------------------------------------
INSERT INTO propiedad_caracteristica (id_propiedad, id_caracteristica, cantidad) VALUES
  (1, 1, 3), (1, 2, 2), (1, 3, 1), (1, 4, 74), (1, 7, 4), (1, 9, 1), (1, 10, 1),
  (2, 1, 4), (2, 2, 3), (2, 3, 2), (2, 4, 160), (2, 5, 200), (2, 7, 3), (2, 9, 1),
  (3, 3, 1), (3, 4, 48), (3, 7, 4),
  (4, 4, 90), (4, 7, 4),
  (5, 5, 1200), (5, 6, 0),
  (6, 1, 5), (6, 2, 4), (6, 3, 3), (6, 4, 240), (6, 5, 800), (6, 7, 2), (6, 8, 1),
  (7, 1, 3), (7, 2, 2), (7, 3, 1), (7, 4, 68), (7, 7, 3),
  (8, 3, 4), (8, 4, 320), (8, 6, 10),
  (9, 1, 2), (9, 2, 1), (9, 4, 54), (9, 7, 3),
  (10, 3, 1), (10, 4, 40), (10, 7, 4),
  (11, 1, 3), (11, 2, 2), (11, 4, 120), (11, 5, 140), (11, 7, 2),
  (12, 1, 3), (12, 2, 2), (12, 4, 85), (12, 7, 4);

-- ---------------------------------------------------------------------
-- IMAGENES DE PROPIEDAD
-- Galeria local: cada propiedad usa 2 a 4 fotos coherentes con su tipo.
-- Los archivos viven en img/propiedades/ (fotos reales de bancos libres,
-- descargadas y validadas de Pexels/Unsplash).
-- Nota: existen archivos para Finca, Apartaestudio, Consultorio y
-- Parqueadero (img/propiedades/) que hoy no tienen propiedad asignada.
-- ---------------------------------------------------------------------
DELETE FROM imagen_propiedad;
INSERT INTO imagen_propiedad (id_imagen, id_propiedad, url_imagen, orden) VALUES
  -- Apartamento
  (1,  1,  '/inmobiliaria_uts/img/propiedades/apartamento_01.jpg',  1),
  (2,  1,  '/inmobiliaria_uts/img/propiedades/apartamento_02.jpg',  2),
  (3,  1,  '/inmobiliaria_uts/img/propiedades/apartamento_03.jpg',  3),
  (4,  7,  '/inmobiliaria_uts/img/propiedades/apartamento_01.jpg',  1),
  (5,  7,  '/inmobiliaria_uts/img/propiedades/apartamento_02.jpg',  2),
  (6,  7,  '/inmobiliaria_uts/img/propiedades/apartamento_03.jpg',  3),
  (7,  9,  '/inmobiliaria_uts/img/propiedades/apartamento_01.jpg',  1),
  (8,  9,  '/inmobiliaria_uts/img/propiedades/apartamento_02.jpg',  2),
  (9,  9,  '/inmobiliaria_uts/img/propiedades/apartamento_03.jpg',  3),
  (10, 12, '/inmobiliaria_uts/img/propiedades/apartamento_01.jpg',  1),
  (11, 12, '/inmobiliaria_uts/img/propiedades/apartamento_02.jpg',  2),
  (12, 12, '/inmobiliaria_uts/img/propiedades/apartamento_03.jpg',  3),
  -- Casa
  (13, 2,  '/inmobiliaria_uts/img/propiedades/casa_01.jpg',  1),
  (14, 2,  '/inmobiliaria_uts/img/propiedades/casa_02.jpg',  2),
  (15, 2,  '/inmobiliaria_uts/img/propiedades/casa_03.jpg',  3),
  (16, 6,  '/inmobiliaria_uts/img/propiedades/casa_01.jpg',  1),
  (17, 6,  '/inmobiliaria_uts/img/propiedades/casa_02.jpg',  2),
  (18, 6,  '/inmobiliaria_uts/img/propiedades/casa_03.jpg',  3),
  (19, 11, '/inmobiliaria_uts/img/propiedades/casa_01.jpg',  1),
  (20, 11, '/inmobiliaria_uts/img/propiedades/casa_02.jpg',  2),
  -- Local Comercial
  (21, 3,  '/inmobiliaria_uts/img/propiedades/local_01.jpg',  1),
  (22, 3,  '/inmobiliaria_uts/img/propiedades/local_02.jpg',  2),
  (23, 3,  '/inmobiliaria_uts/img/propiedades/local_03.jpg',  3),
  (24, 10, '/inmobiliaria_uts/img/propiedades/local_01.jpg',  1),
  (25, 10, '/inmobiliaria_uts/img/propiedades/local_02.jpg',  2),
  (26, 10, '/inmobiliaria_uts/img/propiedades/local_03.jpg',  3),
  -- Oficina
  (27, 4,  '/inmobiliaria_uts/img/propiedades/oficina_01.jpg',  1),
  (28, 4,  '/inmobiliaria_uts/img/propiedades/oficina_02.jpg',  2),
  (29, 4,  '/inmobiliaria_uts/img/propiedades/oficina_03.jpg',  3),
  -- Lote
  (30, 5,  '/inmobiliaria_uts/img/propiedades/lote_01.jpg',  1),
  (31, 5,  '/inmobiliaria_uts/img/propiedades/lote_02.jpg',  2),
  -- Bodega
  (32, 8,  '/inmobiliaria_uts/img/propiedades/bodega_01.jpg',  1),
  (33, 8,  '/inmobiliaria_uts/img/propiedades/bodega_02.jpg',  2);

-- ---------------------------------------------------------------------
-- CITAS (cliente agenda visita a la propiedad)
-- ---------------------------------------------------------------------
INSERT INTO cita (id_cita, id_propiedad, id_cliente, fecha_hora, estado) VALUES
  (1, 1,  6,  '2026-09-15 10:00:00', 'pendiente'),
  (2, 1,  7,  '2026-09-18 15:00:00', 'confirmada'),
  (3, 2,  8,  '2026-09-16 09:30:00', 'pendiente'),
  (4, 3,  9,  '2026-09-17 11:00:00', 'pendiente'),
  (5, 5,  10, '2026-09-20 14:00:00', 'cancelada'),
  (6, 7,  6,  '2026-09-22 10:00:00', 'confirmada'),
  (7, 4,  7,  '2026-10-02 08:30:00', 'pendiente'),
  (8, 10, 8,  '2026-10-05 16:00:00', 'pendiente'),
  (9, 2,  9,  '2026-10-08 11:00:00', 'pendiente'),
  (10, 12, 6, '2026-10-10 09:00:00', 'confirmada');

-- ---------------------------------------------------------------------
-- SOLICITUDES (compra / arriendo)
-- ---------------------------------------------------------------------
INSERT INTO solicitud (id_solicitud, id_propiedad, id_cliente, tipo, estado, fecha_solicitud) VALUES
  (1,  1,  6,  'compra',  'pendiente',  '2026-09-01 10:00:00'),
  (2,  2,  7,  'compra',  'aprobada',   '2026-09-02 12:00:00'),
  (3,  4,  8,  'arriendo','aprobada',   '2026-09-03 09:00:00'),
  (4,  3,  9,  'compra',  'rechazada',  '2026-09-04 11:00:00'),
  (5,  5,  10, 'compra',  'pendiente',  '2026-09-05 15:00:00'),
  (6,  6,  6,  'compra',  'pendiente',  '2026-09-06 10:00:00'),
  (7,  9,  7,  'arriendo','pendiente',  '2026-09-07 08:30:00'),
  (8,  8,  8,  'compra',  'pendiente',  '2026-09-08 14:00:00'),
  (9,  12, 9,  'compra',  'pendiente',  '2026-09-09 09:00:00'),
  (10, 2,  10, 'arriendo','aprobada',   '2026-09-10 16:00:00');

-- ---------------------------------------------------------------------
-- DOCUMENTOS DE SOLICITUD
-- ---------------------------------------------------------------------
INSERT INTO documento_solicitud (id_documento, id_solicitud, tipo_documento, url_archivo, fecha_carga) VALUES
  (1, 1,  'Cédula de ciudadanía',  'documentos/solicitud_01/cedula.pdf',          '2026-09-01 10:05:00'),
  (2, 1,  'Certificado laboral',   'documentos/solicitud_01/certificado.pdf',     '2026-09-01 10:10:00'),
  (3, 2,  'Cédula de ciudadanía',  'documentos/solicitud_02/cedula.pdf',          '2026-09-02 12:05:00'),
  (4, 2,  'Extracto bancario',     'documentos/solicitud_02/extracto.pdf',        '2026-09-02 12:10:00'),
  (5, 3,  'Cédula de ciudadanía',  'documentos/solicitud_03/cedula.pdf',          '2026-09-03 09:05:00'),
  (6, 3,  'Certificado laboral',   'documentos/solicitud_03/certificado.pdf',     '2026-09-03 09:10:00'),
  (7, 4,  'Cédula de ciudadanía',  'documentos/solicitud_04/cedula.pdf',          '2026-09-04 11:05:00'),
  (8, 5,  'Cédula de ciudadanía',  'documentos/solicitud_05/cedula.pdf',          '2026-09-05 15:05:00'),
  (9, 6,  'Cédula de ciudadanía',  'documentos/solicitud_06/cedula.pdf',          '2026-09-06 10:05:00'),
  (10, 7, 'Certificado laboral',   'documentos/solicitud_07/certificado.pdf',     '2026-09-07 08:35:00');

-- ---------------------------------------------------------------------
-- FAVORITOS (cliente marca propiedades como favoritas)
-- ---------------------------------------------------------------------
INSERT INTO favorito (id_usuario, id_propiedad, fecha_marcado) VALUES
  (6, 1, '2026-09-02 09:00:00'),
  (6, 3, '2026-09-03 10:00:00'),
  (7, 2, '2026-09-04 11:00:00'),
  (8, 4, '2026-09-05 12:00:00'),
  (8, 5, '2026-09-06 13:00:00'),
  (9, 6, '2026-09-07 14:00:00'),
  (10, 7, '2026-09-08 15:00:00'),
  (10, 8, '2026-09-09 16:00:00'),
  (6, 12, '2026-09-10 09:00:00'),
  (9, 10, '2026-09-10 10:30:00');

-- ---------------------------------------------------------------------
-- AUDITORIA
-- ---------------------------------------------------------------------
INSERT INTO auditoria (id_auditoria, id_usuario, accion, fecha_hora, detalle) VALUES
  (1, 1, 'LOGIN',        '2026-09-10 08:00:00', 'Inicio de sesión exitoso del administrador'),
  (2, 3, 'LOGIN',        '2026-09-10 08:05:00', 'Inicio de sesión exitoso de la inmobiliaria'),
  (3, 3, 'CREAR_PROP',   '2026-09-10 08:20:00', 'Publicó el apartamento de Cabecera'),
  (4, 5, 'APROBAR_CITA', '2026-09-10 09:00:00', 'Confirmó cita de la propiedad 1'),
  (5, 6, 'CREAR_SOLIC',  '2026-09-11 10:00:00', 'Radicó solicitud de compra sobre propiedad 1'),
  (6, 1, 'ELIMINAR_PROP','2026-09-11 11:30:00', 'Baja lógica de la casa en Altos de Girón'),
  (7, 3, 'CREAR_PROP',     '2026-09-12 09:30:00', 'Publicó la bodega de la zona industrial'),
  (8, 4, 'APROBAR_SOLIC',  '2026-09-12 10:15:00', 'Aprobó solicitud de arriendo de la oficina Libertadores'),
  (9, 8, 'CREAR_SOLIC',    '2026-09-12 11:00:00', 'Radicó solicitud de compra sobre la bodega'),
  (10, 1, 'BLOQUEO_LOGIN', '2026-09-12 12:45:00', 'Se rechazó el acceso de usuario inactivo');