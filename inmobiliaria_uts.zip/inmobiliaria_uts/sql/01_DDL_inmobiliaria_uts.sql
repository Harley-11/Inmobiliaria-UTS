-- =====================================================================
-- INMOBILIARIA UTS - SCRIPT DDL
-- Unidades Tecnologicas de Santander
-- Motor: MySQL / MariaDB (XAMPP)
-- Charset: utf8mb4 / utf8mb4_unicode_ci
-- =====================================================================

CREATE DATABASE IF NOT EXISTS inmobiliaria_uts
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE inmobiliaria_uts;

-- ---------------------------------------------------------------------
-- POLITICA DE LLAVES FORANEAS (justificacion):
--  * CASCADE en hijos "parte-de" (agregados): si se borra el padre,
--    sus registros hijos se van con el (perfil, usuario_rol, imagenes,
--    caracteristicas de propiedad, documentos de solicitud, favoritos,
--    citas y solicitudes del cliente, propiedades de la inmobiliaria).
--  * RESTRICT en datos maestros/referencia referenciados por registros
--    de negocio: no se puede borrar una ciudad, tipo, caracteristica o
--    rol que este en uso. Tampoco el usuario dueno de una inmobiliaria
--    ni un usuario con trazos de auditoria: para "borrar" se usa baja
--    logica (estado = 'inactivo'), nunca DELETE fisico.
--  * ON UPDATE CASCADE en todos los FK: los PK son AUTO_INCREMENT y
--    rara vez cambian, pero si cambian las FK quedan sincronizadas.
-- =====================================================================

-- 1) rol -----------------------------------------------------------------
CREATE TABLE rol (
  id_rol     INT         NOT NULL AUTO_INCREMENT,
  nombre_rol VARCHAR(30) NOT NULL,
  PRIMARY KEY (id_rol),
  UNIQUE KEY uq_rol_nombre (nombre_rol)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2) usuario --------------------------------------------------------------
CREATE TABLE usuario (
  id_usuario      INT          NOT NULL AUTO_INCREMENT,
  correo          VARCHAR(100) NOT NULL,
  contrasena_hash VARCHAR(255) NOT NULL,
  estado          VARCHAR(20)  NOT NULL DEFAULT 'activo',
  fecha_registro  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_usuario),
  UNIQUE KEY uq_usuario_correo (correo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3) usuario_rol (N:M) ----------------------------------------------------
CREATE TABLE usuario_rol (
  id_usuario INT NOT NULL,
  id_rol     INT NOT NULL,
  PRIMARY KEY (id_usuario, id_rol),
  CONSTRAINT fk_usuario_rol_usuario
    FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_usuario_rol_rol
    FOREIGN KEY (id_rol) REFERENCES rol (id_rol)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4) perfil (1:1 con usuario) ---------------------------------------------
CREATE TABLE perfil (
  id_perfil  INT          NOT NULL AUTO_INCREMENT,
  id_usuario INT          NOT NULL,
  nombres    VARCHAR(60)  NOT NULL,
  apellidos  VARCHAR(60)  NOT NULL,
  documento  VARCHAR(20)  NOT NULL,
  telefono   VARCHAR(15)  NULL,
  direccion  VARCHAR(150) NULL,
  foto       VARCHAR(255) NULL,
  PRIMARY KEY (id_perfil),
  UNIQUE KEY uq_perfil_id_usuario (id_usuario),
  CONSTRAINT fk_perfil_usuario
    FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5) inmobiliaria -----------------------------------------------------------
CREATE TABLE inmobiliaria (
  id_inmobiliaria INT          NOT NULL AUTO_INCREMENT,
  id_usuario      INT          NOT NULL,
  nombre_comercial VARCHAR(100) NOT NULL,
  nit             VARCHAR(20)  NULL,
  PRIMARY KEY (id_inmobiliaria),
  UNIQUE KEY uq_inmobiliaria_nit (nit),
  CONSTRAINT fk_inmobiliaria_usuario
    FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6) ciudad ----------------------------------------------------------------
CREATE TABLE ciudad (
  id_ciudad    INT         NOT NULL AUTO_INCREMENT,
  nombre_ciudad VARCHAR(60) NOT NULL,
  departamento VARCHAR(60) NULL,
  PRIMARY KEY (id_ciudad)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7) tipo_propiedad --------------------------------------------------------
CREATE TABLE tipo_propiedad (
  id_tipo     INT         NOT NULL AUTO_INCREMENT,
  nombre_tipo VARCHAR(30) NOT NULL,
  PRIMARY KEY (id_tipo),
  UNIQUE KEY uq_tipo_nombre (nombre_tipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8) propiedad --------------------------------------------------------------
CREATE TABLE propiedad (
  id_propiedad           INT           NOT NULL AUTO_INCREMENT,
  id_inmobiliaria        INT           NOT NULL,
  id_ciudad              INT           NOT NULL,
  id_tipo                INT           NOT NULL,
  matricula_inmobiliaria VARCHAR(30)   NOT NULL,
  titulo                 VARCHAR(120)  NOT NULL,
  descripcion            TEXT          NULL,
  precio                 DECIMAL(12,2) NOT NULL,
  direccion              VARCHAR(150)  NULL,
  estado                 VARCHAR(20)   NOT NULL DEFAULT 'disponible',
  fecha_publicacion      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_propiedad),
  UNIQUE KEY uq_propiedad_matricula (matricula_inmobiliaria),
  CONSTRAINT fk_propiedad_inmobiliaria
    FOREIGN KEY (id_inmobiliaria) REFERENCES inmobiliaria (id_inmobiliaria)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_propiedad_ciudad
    FOREIGN KEY (id_ciudad) REFERENCES ciudad (id_ciudad)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_propiedad_tipo
    FOREIGN KEY (id_tipo) REFERENCES tipo_propiedad (id_tipo)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9) imagen_propiedad (1:N desde propiedad) ---------------------------------
CREATE TABLE imagen_propiedad (
  id_imagen    INT          NOT NULL AUTO_INCREMENT,
  id_propiedad INT          NOT NULL,
  url_imagen   VARCHAR(255) NOT NULL,
  orden        INT          NOT NULL DEFAULT 1,
  PRIMARY KEY (id_imagen),
  CONSTRAINT fk_imagen_propiedad
    FOREIGN KEY (id_propiedad) REFERENCES propiedad (id_propiedad)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10) caracteristica ---------------------------------------------------------
CREATE TABLE caracteristica (
  id_caracteristica     INT         NOT NULL AUTO_INCREMENT,
  nombre_caracteristica VARCHAR(50) NOT NULL,
  PRIMARY KEY (id_caracteristica),
  UNIQUE KEY uq_caracteristica_nombre (nombre_caracteristica)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11) propiedad_caracteristica (N:M) ----------------------------------------
CREATE TABLE propiedad_caracteristica (
  id_propiedad      INT NOT NULL,
  id_caracteristica INT NOT NULL,
  cantidad          INT NOT NULL DEFAULT 1,
  PRIMARY KEY (id_propiedad, id_caracteristica),
  CONSTRAINT fk_prop_caract_propiedad
    FOREIGN KEY (id_propiedad) REFERENCES propiedad (id_propiedad)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_prop_caract_caracteristica
    FOREIGN KEY (id_caracteristica) REFERENCES caracteristica (id_caracteristica)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12) cita --------------------------------------------------------------------
CREATE TABLE cita (
  id_cita      INT      NOT NULL AUTO_INCREMENT,
  id_propiedad INT      NOT NULL,
  id_cliente   INT      NOT NULL,
  fecha_hora   DATETIME NOT NULL,
  estado       VARCHAR(20) NOT NULL DEFAULT 'pendiente',
  PRIMARY KEY (id_cita),
  UNIQUE KEY uq_cita_propiedad_fecha (id_propiedad, fecha_hora),
  CONSTRAINT fk_cita_propiedad
    FOREIGN KEY (id_propiedad) REFERENCES propiedad (id_propiedad)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_cita_cliente
    FOREIGN KEY (id_cliente) REFERENCES usuario (id_usuario)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13) solicitud -----------------------------------------------------------------
CREATE TABLE solicitud (
  id_solicitud     INT          NOT NULL AUTO_INCREMENT,
  id_propiedad     INT          NOT NULL,
  id_cliente       INT          NOT NULL,
  tipo             VARCHAR(20)  NOT NULL,
  estado           VARCHAR(20)  NOT NULL DEFAULT 'pendiente',
  fecha_solicitud  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_solicitud),
  KEY idx_solicitud_propiedad (id_propiedad),
  KEY idx_solicitud_cliente (id_cliente),
  CONSTRAINT fk_solicitud_propiedad
    FOREIGN KEY (id_propiedad) REFERENCES propiedad (id_propiedad)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_solicitud_cliente
    FOREIGN KEY (id_cliente) REFERENCES usuario (id_usuario)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14) documento_solicitud (1:N desde solicitud) -------------------------------
CREATE TABLE documento_solicitud (
  id_documento   INT          NOT NULL AUTO_INCREMENT,
  id_solicitud   INT          NOT NULL,
  tipo_documento VARCHAR(50)  NOT NULL,
  url_archivo    VARCHAR(255) NOT NULL,
  fecha_carga    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_documento),
  CONSTRAINT fk_doc_solicitud
    FOREIGN KEY (id_solicitud) REFERENCES solicitud (id_solicitud)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15) favorito (N:M usuario-propiedad) -----------------------------------------
CREATE TABLE favorito (
  id_usuario     INT      NOT NULL,
  id_propiedad   INT      NOT NULL,
  fecha_marcado  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_usuario, id_propiedad),
  CONSTRAINT fk_favorito_usuario
    FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_favorito_propiedad
    FOREIGN KEY (id_propiedad) REFERENCES propiedad (id_propiedad)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16) auditoria -----------------------------------------------------------------
CREATE TABLE auditoria (
  id_auditoria INT          NOT NULL AUTO_INCREMENT,
  id_usuario   INT          NOT NULL,
  accion       VARCHAR(100) NOT NULL,
  fecha_hora   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  detalle      TEXT         NULL,
  PRIMARY KEY (id_auditoria),
  KEY idx_auditoria_usuario (id_usuario),
  CONSTRAINT fk_auditoria_usuario
    FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;