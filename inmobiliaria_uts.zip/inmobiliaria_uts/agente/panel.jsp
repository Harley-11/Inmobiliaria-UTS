<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*" %>
<%--
 agente/panel.jsp - Panel del rol inmobiliaria: resumen y acceso rapido.
 Protegido por el fragmento seguridad.jspf (rolesPermitidos) y por
 SeguridadFilter (ruta /agente/*). El agente gestiona las propiedades de
 SU inmobiliaria (inmobiliaria.id_usuario = sesion).
--%>
<%
  String[] rolesPermitidos = { "inmobiliaria" };
  String tituloPagina = "Panel de la inmobiliaria";
%>
<%@ include file="/WEB-INF/jspf/seguridad.jspf" %>
<%@ include file="/WEB-INF/jspf/conexion.jspf" %>
<%
  int idUsuario = ((Integer) session.getAttribute("idUsuario")).intValue();

  int idInmobiliaria = 0;
  String nombreInmobiliaria = null;
  int totalPropiedades = 0;
  int disponibles = 0;
  int inactivas = 0;
  int solicitudesPendientes = 0;
  String errorPanel = null;

  Connection con = null;
  PreparedStatement ps = null;
  ResultSet rs = null;
  try {
    con = abrirConexion();
    idInmobiliaria = idInmobiliariaDeUsuario(con, idUsuario);

    if (idInmobiliaria > 0) {
      ps = con.prepareStatement(
          "SELECT nombre_comercial FROM inmobiliaria WHERE id_inmobiliaria = ?");
      ps.setInt(1, idInmobiliaria);
      rs = ps.executeQuery();
      if (rs.next()) nombreInmobiliaria = rs.getString(1);
      cerrar(rs, ps);

      ps = con.prepareStatement(
          "SELECT COUNT(*), " +
          "SUM(CASE WHEN estado = 'disponible' THEN 1 ELSE 0 END), " +
          "SUM(CASE WHEN estado = 'inactivo' THEN 1 ELSE 0 END) " +
          "FROM propiedad WHERE id_inmobiliaria = ?");
      ps.setInt(1, idInmobiliaria);
      rs = ps.executeQuery();
      if (rs.next()) {
        totalPropiedades = rs.getInt(1);
        disponibles = rs.getInt(2);
        inactivas = rs.getInt(3);
      }
      cerrar(rs, ps);

      ps = con.prepareStatement(
          "SELECT COUNT(*) FROM solicitud s " +
          "JOIN propiedad p ON p.id_propiedad = s.id_propiedad " +
          "WHERE p.id_inmobiliaria = ? AND s.estado = 'pendiente'");
      ps.setInt(1, idInmobiliaria);
      rs = ps.executeQuery();
      if (rs.next()) solicitudesPendientes = rs.getInt(1);
    }
  } catch (Exception e) {
    e.printStackTrace();
    errorPanel = "No se pudo cargar el resumen. Intente mas tarde.";
  } finally {
    cerrar(rs, ps, con);
  }
%>
<%@ include file="/WEB-INF/jspf/cabecera.jspf" %>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
    <div>
        <h1 class="h4 fw-bold mb-1">Panel de la inmobiliaria</h1>
        <p class="text-muted mb-0">Bienvenido, <%=esc(nombreSesion)%>.</p>
    </div>
    <a class="btn ims-btn rounded-pill px-4" href="<%=ctx%>/agente/propiedad_editar.jsp">
        <i class="bi bi-plus-lg me-1"></i> Publicar propiedad
    </a>
</div>

<% if (errorPanel != null) { %>
    <div class="alert alert-danger rounded-4"><i class="bi bi-exclamation-triangle me-1"></i><%=errorPanel%></div>
<% } %>

<% if (idInmobiliaria <= 0) { %>
    <div class="alert alert-warning rounded-4">
        <i class="bi bi-exclamation-triangle me-1"></i>
        Su cuenta no tiene una inmobiliaria asociada en el sistema.
        Contacte al administrador para que le asigne una antes de gestionar propiedades.
    </div>
<% } %>

<div class="row g-3">
    <div class="col-md-4">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <span class="ims-stat-icon"><i class="bi bi-building"></i></span>
                    <div>
                        <div class="text-muted small">Inmobiliaria</div>
                        <div class="fw-bold fs-6"><%=esc(nombreInmobiliaria == null ? "Sin asignar" : nombreInmobiliaria)%></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <span class="ims-stat-icon"><i class="bi bi-list-check"></i></span>
                    <div>
                        <div class="text-muted small">Propiedades</div>
                        <div class="fw-bold fs-3"><%=totalPropiedades%></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex align-items-center gap-3">
                    <span class="ims-stat-icon"><i class="bi bi-bag-check"></i></span>
                    <div>
                        <div class="text-muted small">Disponibles / Inactivas</div>
                        <div class="fw-bold fs-3"><%=disponibles%> <span class="text-secondary fs-6">/ <%=inactivas%></span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mt-2">
    <div class="col-md-6">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-header bg-transparent fw-bold"><i class="bi bi-house-plus me-1"></i> Gestionar propiedades</div>
            <div class="card-body">
                <ul class="list-unstyled mb-0 small">
                    <li class="mb-2"><a class="text-decoration-none" href="<%=ctx%>/agente/propiedades.jsp"><i class="bi bi-list-ul me-1"></i> Ver mis propiedades</a></li>
                    <li class="mb-2"><a class="text-decoration-none" href="<%=ctx%>/agente/propiedad_editar.jsp"><i class="bi bi-plus-circle me-1"></i> Publicar nueva propiedad</a></li>
                    <li class="mb-2"><a class="text-decoration-none" href="<%=ctx%>/agente/solicitudes.jsp"><i class="bi bi-inbox me-1"></i> Bandeja de solicitudes
                        <% if (solicitudesPendientes > 0) { %><span class="badge rounded-pill text-bg-warning ms-1"><%=solicitudesPendientes%> pendiente<%=solicitudesPendientes > 1 ? "s" : ""%></span><% } %>
                    </a></li>
                    <li><span class="text-muted"><i class="bi bi-image me-1"></i> Galeria de imagenes y caracteristicas se administran desde cada propiedad.</span></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card ims-card shadow-sm h-100">
            <div class="card-header bg-transparent fw-bold"><i class="bi bi-info-circle me-1"></i> Recuerde</div>
            <div class="card-body small text-muted">
                <p class="mb-1">Los visitantes solo ven propiedades en estado <strong>disponible</strong>.</p>
                <p class="mb-0">Dar de baja una propiedad la oculta del listado publico (cambio a <strong>inactivo</strong>), sin borrarla de la base de datos.</p>
            </div>
        </div>
    </div>
</div>
<%@ include file="/WEB-INF/jspf/utilidades.jspf" %>
<%@ include file="/WEB-INF/jspf/pie.jspf" %>